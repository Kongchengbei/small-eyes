# DDR 时序闭合结果（2026-11-01）

Full DDR 保持 CPU 70 MHz、DDR core 125 MHz。当前 PDS 报告为 **All Constraints Met**，CPU 与 DDR core 两个工艺角的 setup、hold、recovery、removal、最小脉宽均通过。位流已生成，未烧录。

| 检查 | CPU（ns） | DDR core（ns） |
|---|---:|---:|
| Slow setup WNS | +0.799 | +0.040 |
| Fast setup WNS | +6.317 | +2.708 |
| Slow hold WNS | +0.156 | +0.100 |
| Fast hold WNS | +0.108 | +0.099 |
| Slow recovery WNS | +6.594 | +2.317 |
| Fast recovery WNS | +9.495 | +4.484 |
| Slow removal WNS | +0.743 | +0.418 |
| Fast removal WNS | +0.505 | +0.282 |

上表失败端点与负余量总和均为 0。其他已声明时钟域也通过当前约束检查。现有外部端口未指定 input/output delay 等警告仍需结合板级接口验收；不把静态时序通过写成整机功能验收。

资源：SoC 模块 LUT **44422**、FF **47970**、Distributed RAM 1151、APM 69、DRM 35；CPU 模块 LUT **5283**、FF **3685**。器件物理 LUT 48326（CLMA 36651 + CLMS 11675），与模块 LUT 口径不同。

## 修改与模型兼容

- NPU 模型头校验分拍，保留 H×W 低 16 位再乘通道数的原有语义；首次模型加载增加四拍，缓存命中路径不变。
- 旧模型 scratch 计算拆成部分积、重组和对齐，保留全部 32 位回绕和 zero sentinel 行为；需要计算的 GAP 扫描增加三拍。
- 层权重字节数与空间范围检查分拍，每层增加两拍。模型格式、权重/偏置、算子、INT8 量化与真实循环终止条件不变。
- CONV/POOL 末元素周期继续做内部 BRAM 预取，未消费的读数由后续 flush/prime 隔开；不增加 MAC/POOL 主循环周期或外部 AXI 访问。
- 模型 RAM 的权重地址采用逐输出通道递增的运行基址，最终16位地址与原乘法取模结果相同；CONV/POOL 张量地址不再等待坐标边界选择器，原有效位继续屏蔽 padding 的内部无效预取。
- 公共层尺寸、容量和描述符校验寄存在现有元数据阶段，报错优先级不变。非法归还统计采用 pending 事件和基础计数，组合投影保持原可见计数逐拍一致。
- INT8 容量按实际预留/归还维护，防止重复归还重复增加容量；每帧最多八个 ROI、每路 56 个 INT8 位置及位置代次协议不变。

现有模型文件和固件包未修改；可继续用于上板验证。上述兼容性依据代码审查，尚无本轮板上结果或新 CoreMark/识别率/吞吐实测。历史 BRAM 2.67104 CoreMark/MHz 仍只是历史成绩。

## PHY 时钟关系与检查范围

NPU/缓冲的长路径通过 RTL 拆分改善。PHY recovery 按 IP 参考文件的时钟关系分类：采用 DDR IP pnr/ddr_test.fdc:35–37 的三条独立单组声明，对应 ddr_rst_clk、phy_dq_clk_0、phy_dq_clk_1。PDS 手册 6.2.5 中，单组与组外时钟异步，不能误读成两个组外时钟也彼此异步。

已核对 core→phy_dq_sysclk_0/1：双角 setup/hold 仍覆盖 **196/420** 个端点，两个 capture group 各 64 条 slow setup 报告路径均明确为 **MultiCycle Path Setup -end 2**。没有用分组隐藏这些数据路径；没有剩余负 async 路径。同步更新 scripts/soc_config.c，防止 menuconfig 丢失已采纳声明；Full DDR 和隔离 BRAM 的 host 配置检查通过。

时钟周期、原两拍约束、IO 设置和本工程原有 uncertainty 策略均未改变；未恢复 IP 示例额外的 0.4 ns uncertainty。这是当前工程约束下的闭合，不代表把复位线物理传播延迟缩短，也不替代实板 DDR 初始化/训练和数据正确性验收。独立 Timing Analyzer 的自动导入未形成报告，结论只依据正式 PDS 结果。

## 迭代记录

| 版本 | CPU setup WNS | DDR core setup WNS | DDR TNS | DDR 失败端点 |
|---|---:|---:|---:|---:|
| 初始基线 | +0.271 | -2.485 | -9417.415 | 10455 |
| ddr01 | +0.570 | -1.286 | -148.145 | 454 |
| ddr02 | +0.745 | -0.322 | -10.875 | 76 |
| ddr03 | +0.553 | -0.780 | -40.969 | 194 |
| ddr04 | +0.799 | +0.040 | 0.000 | 0 |

## 版本、验证与产物

本轮已验证的 NPU、INT8 缓冲、DDR 约束与配置生成器修改随本次提交纳入 main。PDS 构建时的 Git 基线为9481c57；归档源码与约束保留构建时哈希，CPU、模型和固件未因本轮 DDR 优化修改。本地后续切换的 BRAM 配置及注释编辑另外保留，未纳入本次提交。

完成 Icarus 静态编译、Verilator --lint-only、host 配置检查和 PDS Compile→综合→映射→布局布线→时序→位流生成。保留既有位宽、函数中间变量 LATCH 等 lint 警告，不宣称零警告。没有编写或运行 testbench、RTL 仿真或烧录。

- [原始时序报告](证据/FullDDR_DDR时序闭合_20261031/Hfpga_soc.rtr)、[布线资源报告](证据/FullDDR_DDR时序闭合_20261031/Hfpga_soc.prr)、[结果与检查清单](证据/FullDDR_DDR时序闭合_20261031/result.json)。
- 本轮位流（只保存在原工程归档目录，本资料包不含位流），9188552 字节，SHA256：`47387250ae7cd85bfbadec325d0a60e07a8732d0bf8ae8f26595ef1b4755b025`。根目录 project 中的历史位流不代表本轮产物。
- 详细修改记录见原工程 manual/DDR时序闭合_20261031.md，逐轮记录在 manual/DDR时序优化运行记录/；源码、约束、生成器、静态检查及各阶段日志在 build/ddr_wns_20261031/ddr04_running_addresses_stats_20261101_133951/。
